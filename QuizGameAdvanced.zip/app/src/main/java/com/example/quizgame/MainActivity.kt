package com.example.quizgame

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var questionText: TextView
    private lateinit var optionsGroup: RadioGroup
    private lateinit var nextButton: Button
    private lateinit var categorySpinner: Spinner
    private lateinit var timerText: TextView

    private var currentQuestionIndex = 0
    private var score = 0
    private var selectedCategory = "General"

    private lateinit var questions: List<Question>
    private lateinit var countDownTimer: CountDownTimer
    private val totalTime = 20000L // 20 seconds per question

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        questionText = findViewById(R.id.questionText)
        optionsGroup = findViewById(R.id.optionsGroup)
        nextButton = findViewById(R.id.nextButton)
        categorySpinner = findViewById(R.id.categorySpinner)
        timerText = findViewById(R.id.timerText)

        ArrayAdapter.createFromResource(
            this,
            R.array.categories_array,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            categorySpinner.adapter = adapter
        }

        categorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                selectedCategory = parent.getItemAtPosition(position).toString()
                resetQuiz()
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        nextButton.setOnClickListener {
            val selectedOptionId = optionsGroup.checkedRadioButtonId
            if (selectedOptionId == -1) {
                Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            countDownTimer.cancel()

            val selectedOption = findViewById<RadioButton>(selectedOptionId)
            if (selectedOption.text == questions[currentQuestionIndex].correctAnswer) {
                score++
            }

            currentQuestionIndex++
            if (currentQuestionIndex < questions.size) {
                loadQuestion()
            } else {
                val intent = Intent(this, ResultActivity::class.java)
                intent.putExtra("SCORE", score)
                intent.putExtra("TOTAL", questions.size)
                startActivity(intent)
                finish()
            }
        }
    }

    private fun loadQuestion() {
        val question = questions[currentQuestionIndex]
        questionText.text = question.questionText
        optionsGroup.removeAllViews()

        for (option in question.options) {
            val radioButton = RadioButton(this)
            radioButton.text = option
            optionsGroup.addView(radioButton)
        }

        startTimer()
    }

    private fun startTimer() {
        countDownTimer = object : CountDownTimer(totalTime, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timerText.text = "Time Left: ${millisUntilFinished / 1000}s"
            }

            override fun onFinish() {
                currentQuestionIndex++
                if (currentQuestionIndex < questions.size) {
                    loadQuestion()
                } else {
                    val intent = Intent(this@MainActivity, ResultActivity::class.java)
                    intent.putExtra("SCORE", score)
                    intent.putExtra("TOTAL", questions.size)
                    startActivity(intent)
                    finish()
                }
            }
        }
        countDownTimer.start()
    }

    private fun resetQuiz() {
        currentQuestionIndex = 0
        score = 0
        questions = QuizQuestions.getQuestionsByCategory(selectedCategory)
        loadQuestion()
    }
}
