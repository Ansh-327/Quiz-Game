package com.example.quizgame

object QuizQuestions {
    fun getQuestionsByCategory(category: String): List<Question> {
        val allQuestions = listOf(
            Question("What is the capital of France?", listOf("Paris", "London", "Berlin", "Madrid"), "Paris", "Geography"),
            Question("Who developed the theory of relativity?", listOf("Newton", "Einstein", "Tesla", "Bohr"), "Einstein", "Science"),
            Question("Which planet is known as the Red Planet?", listOf("Earth", "Mars", "Venus", "Jupiter"), "Mars", "Science"),
            Question("What is the largest ocean?", listOf("Atlantic", "Indian", "Pacific", "Arctic"), "Pacific", "Geography"),
            Question("What is 5 + 7?", listOf("10", "11", "12", "13"), "12", "General")
        )
        return allQuestions.filter { it.category == category || category == "General" }
    }
}
